import { Controller } from "@hotwired/stimulus";

// Connects to data-controller="edit-movie"
export default class extends Controller {
  static targets = ["form"];

  connect() {}

  toggleForm() {
    console.log(this.formTarget);
    this.formTarget.classList.toggle("d-none");
  }

  update(event) {
    event.preventDefault();
    const form = new FormData(this.formTarget);
    const url = this.formTarget.action;
    fetch(url, {
      method: "PATCH",
      headers: {
        Accept: "text/plain",
      },
      body: form,
    })
      .then((response) => response.text())
      .then((html) => {
        this.element.outerHTML = html;
      });
  }
}
