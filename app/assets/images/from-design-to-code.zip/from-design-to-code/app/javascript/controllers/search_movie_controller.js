import { Controller } from "@hotwired/stimulus";

// Connects to data-controller="search-movie"
export default class extends Controller {
  static targets = ["form", "input", "list"];

  search() {
    const newQuery = `${this.formTarget.action}?query=${this.inputTarget.value}`;
    fetch(newQuery, {
      headers: {
        Accept: "text/plain",
      },
    })
      .then((response) => response.text())
      .then((html) => {
        this.listTarget.outerHTML = html;
      });
  }
}
